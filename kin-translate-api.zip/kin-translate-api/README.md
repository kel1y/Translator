# English → Kinyarwanda Translation API

Serves `Maxime-Bakunzi/twigane-en-kin-translation` (1B params, NLLB fine-tuned
for en→kin) via CTranslate2 with int8 quantization, for fast inference on a
CPU-only machine.

**Why this model, not NLLB-200-3.3B:** the 3.3B model is a 200-language
generalist, ~3x the size, and far too slow on CPU (tens of seconds per
sentence even quantized). Twigane is 1B params and fine-tuned specifically
for this language pair — smaller, faster, and specialized where it counts.
Neither model has a free hosted inference API on Hugging Face (confirmed:
Twigane's model page shows it isn't deployed by any Inference Provider), so
this self-hosted route is the only free option for either.

**Heads up about the Twigane repo itself:** its `config.json` is broken —
it's a 4-key metadata file, not a real `transformers` config (no
`model_type`, no architecture fields). That means the usage snippet on the
model card (`AutoModelForSeq2SeqLM.from_pretrained(...)`) will fail as-is
with `ValueError: Unrecognized model`, the same error you'd get converting
it directly. `convert_model.sh` works around this automatically by pulling
the real config from the base model it was fine-tuned from
(`mbazaNLP/Nllb_finetuned_general_en_kin`, same architecture) and using that
instead — you don't need to do anything extra.

---

## Option A — Run directly on the VPS (no Docker)

```bash
# 1. Unzip and enter the project
unzip kin-translate-api.zip
cd kin-translate-api

# 2. Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies (CPU-only torch, smaller download)
pip install --index-url https://download.pytorch.org/whl/cpu torch==2.4.1
pip install -r requirements.txt

# 4. Download the model from Hugging Face and convert it to
#    quantized CTranslate2 format. This needs internet access
#    and takes a few minutes.
chmod +x convert_model.sh
./convert_model.sh

# 5. Start the API (8001, since 8000 is already in use on your server)
uvicorn app:app --host 0.0.0.0 --port 8001
```

Leave that running (or run it under `systemd`/`tmux`/`pm2` so it survives
disconnecting), then in another shell:

```bash
chmod +x test_api.sh
./test_api.sh
```

## Option B — Docker (matches your existing Hetzner + Caddy setup)

The model is downloaded and converted at **build time**, so the container
starts instantly and doesn't need Hugging Face access at runtime.

```bash
unzip kin-translate-api.zip
cd kin-translate-api

docker compose build      # downloads + converts the model, several minutes
docker compose up -d

# check it came up
docker compose logs -f
curl http://localhost:8001/health
```

Note: the container listens on port 8000 *internally*, but is published on
**8001** on the host (see `docker-compose.yml`) since you already have
something on 8000. If that other service is also in Docker, both can coexist
fine — Docker gives each container its own network namespace, so two
containers can each use port 8000 *inside* themselves with zero conflict; it
only matters which host port you map them to.

To put it behind Caddy the way you've done with Incode: uncomment the
`caddy_net` network lines in `docker-compose.yml`, drop the `ports:` mapping
if you don't want it exposed directly, and add a site block to your
`Caddyfile` pointing at `kin-translate-api:8000`.

---

## Using the API

```bash
curl -X POST http://localhost:8001/translate \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, how are you today?"}'
```

Response:

```json
{
  "translation": "Muraho, amakuru yawe?",
  "source_lang": "eng_Latn",
  "target_lang": "kin_Latn",
  "latency_ms": 842.3
}
```

Batch endpoint (`POST /translate/batch`) accepts `{"texts": [...]}` for up
to 50 strings in one request — cheaper per-sentence than calling
`/translate` in a loop.

---

## Performance tuning on CPU

Environment variables (set in `docker-compose.yml` or your shell before
`uvicorn`):

| Variable | Default | Effect |
|---|---|---|
| `CT2_INTRA_THREADS` | 4 | CPU threads per translation. Raise toward your core count for lower per-request latency. |
| `CT2_INTER_THREADS` | 1 | Parallel requests processed simultaneously. Raise if you expect concurrent traffic and have cores to spare (trades off against `INTRA_THREADS`). |
| `BEAM_SIZE` | 4 | Lower (e.g. 1 = greedy) for faster but slightly less accurate translations; raise for quality at the cost of speed. |

Rule of thumb: `INTER_THREADS × INTRA_THREADS` shouldn't exceed your VPS's
CPU core count.

If you later want to try `NLLB-200-3.3B` for comparison despite the
slowness, the same `convert_model.sh` pattern works — just swap
`MODEL_ID` to `facebook/nllb-200-3.3B` — but expect several times more RAM
and much higher per-request latency on CPU.

## Files

- `app.py` — FastAPI service (`/translate`, `/translate/batch`, `/health`)
- `convert_model.sh` — downloads the model from HF and converts it to int8 CTranslate2 format
- `requirements.txt` — Python dependencies
- `Dockerfile` / `docker-compose.yml` — containerized deployment
- `test_api.sh` — smoke-test script

## Troubleshooting

**`ValueError: Unrecognized model in Maxime-Bakunzi/twigane-en-kin-translation`**
Already handled by `convert_model.sh` (see note above) — if you still hit
this, check that the script's config-patching step ran and printed "Patched
twigane_raw/config.json..." before the conversion step started.

**Translations come out in the wrong language, or garbled**
This model doesn't set a `forced_bos_token_id`, so by default the API
relies on the model's own `decoder_start_token_id` to produce Kinyarwanda
(matching the official usage snippet's behavior exactly). If output looks
wrong, force the target-language token explicitly:
```bash
# docker-compose.yml — add under environment:
- TGT_LANG=kin_Latn
```
or `export TGT_LANG=kin_Latn` before running `uvicorn` directly, then
reconvert/restart.

**`ImportError: libctranslate2-....so: cannot enable executable stack ...`**
This happens when the OS has glibc 2.41+ (e.g. Debian 13/"trixie", Ubuntu
25.04+) — CTranslate2's compiled library requests an executable stack that
newer glibc refuses to grant. The Docker build in this project is already
pinned to `python:3.11-slim-bookworm` (glibc 2.36) to avoid it. If you hit
this running **Option A directly on the VPS** (no Docker) and `lsb_release
-a` shows a newer OS release, either:
- run everything inside the provided Docker setup instead (Option B), or
- install `patchelf` and clear the flag on the installed library:
  ```bash
  pip install patchelf
  find venv -name "libctranslate2-*.so*" -exec patchelf --clear-execstack {} \;
  ```
