# English → Kinyarwanda Translation API

Serves `Maxime-Bakunzi/twigane-en-kin-translation` (1B params, NLLB fine-tuned
for en→kin) via CTranslate2 with int8 quantization, for fast inference on a
CPU-only machine.

**Why this model, not NLLB-200-3.3B:** the 3.3B model is a 200-language
generalist, ~3x the size, and far too slow on CPU (tens of seconds per
sentence even quantized). Twigane is 1B params and fine-tuned specifically
for this language pair — smaller, faster, and specialized where it counts.
Neither model has a free hosted inference API on Hugging Face (confirmed:
Twigane's model page shows it isn't deployed by any Inference Provider), so
this self-hosted route is the only free option for either.

---

## Option A — Run directly on the VPS (no Docker)

```bash
# 1. Unzip and enter the project
unzip kin-translate-api.zip
cd kin-translate-api

# 2. Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies (CPU-only torch, smaller download)
pip install --index-url https://download.pytorch.org/whl/cpu torch==2.4.1
pip install -r requirements.txt

# 4. Download the model from Hugging Face and convert it to
#    quantized CTranslate2 format. This needs internet access
#    and takes a few minutes.
chmod +x convert_model.sh
./convert_model.sh

# 5. Start the API (8001, since 8000 is already in use on your server)
uvicorn app:app --host 0.0.0.0 --port 8001
```

Leave that running (or run it under `systemd`/`tmux`/`pm2` so it survives
disconnecting), then in another shell:

```bash
chmod +x test_api.sh
./test_api.sh
```

## Option B — Docker (matches your existing Hetzner + Caddy setup)

The model is downloaded and converted at **build time**, so the container
starts instantly and doesn't need Hugging Face access at runtime.

```bash
unzip kin-translate-api.zip
cd kin-translate-api

docker compose build      # downloads + converts the model, several minutes
docker compose up -d

# check it came up
docker compose logs -f
curl http://localhost:8001/health
```

Note: the container listens on port 8000 *internally*, but is published on
**8001** on the host (see `docker-compose.yml`) since you already have
something on 8000. If that other service is also in Docker, both can coexist
fine — Docker gives each container its own network namespace, so two
containers can each use port 8000 *inside* themselves with zero conflict; it
only matters which host port you map them to.

To put it behind Caddy the way you've done with Incode: uncomment the
`caddy_net` network lines in `docker-compose.yml`, drop the `ports:` mapping
if you don't want it exposed directly, and add a site block to your
`Caddyfile` pointing at `kin-translate-api:8000`.

---

## Using the API

```bash
curl -X POST http://localhost:8001/translate \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, how are you today?"}'
```

Response:

```json
{
  "translation": "Muraho, amakuru yawe?",
  "source_lang": "eng_Latn",
  "target_lang": "kin_Latn",
  "latency_ms": 842.3
}
```

Batch endpoint (`POST /translate/batch`) accepts `{"texts": [...]}` for up
to 50 strings in one request — cheaper per-sentence than calling
`/translate` in a loop.

---

## Performance tuning on CPU

Environment variables (set in `docker-compose.yml` or your shell before
`uvicorn`):

| Variable | Default | Effect |
|---|---|---|
| `CT2_INTRA_THREADS` | 4 | CPU threads per translation. Raise toward your core count for lower per-request latency. |
| `CT2_INTER_THREADS` | 1 | Parallel requests processed simultaneously. Raise if you expect concurrent traffic and have cores to spare (trades off against `INTRA_THREADS`). |
| `BEAM_SIZE` | 4 | Lower (e.g. 1 = greedy) for faster but slightly less accurate translations; raise for quality at the cost of speed. |

Rule of thumb: `INTER_THREADS × INTRA_THREADS` shouldn't exceed your VPS's
CPU core count.

If you later want to try `NLLB-200-3.3B` for comparison despite the
slowness, the same `convert_model.sh` pattern works — just swap
`MODEL_ID` to `facebook/nllb-200-3.3B` — but expect several times more RAM
and much higher per-request latency on CPU.

## Files

- `app.py` — FastAPI service (`/translate`, `/translate/batch`, `/health`)
- `convert_model.sh` — downloads the model from HF and converts it to int8 CTranslate2 format
- `requirements.txt` — Python dependencies
- `Dockerfile` / `docker-compose.yml` — containerized deployment
- `test_api.sh` — smoke-test script
