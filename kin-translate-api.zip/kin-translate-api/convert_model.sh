#!/usr/bin/env bash
# Downloads Maxime-Bakunzi/twigane-en-kin-translation from Hugging Face and
# converts it into an int8-quantized CTranslate2 model for fast CPU inference.
#
# Run this ONCE before starting the API. It needs internet access to
# huggingface.co and will take a few minutes (downloads ~4GB of fp32 weights,
# converted output is much smaller, ~1GB in int8).

set -euo pipefail

MODEL_ID="Maxime-Bakunzi/twigane-en-kin-translation"
OUT_DIR="ct2_model"
TOKENIZER_DIR="tokenizer"

echo ">> Converting ${MODEL_ID} to CTranslate2 (int8 quantization)..."
ct2-transformers-converter \
  --model "${MODEL_ID}" \
  --output_dir "${OUT_DIR}" \
  --quantization int8 \
  --force

echo ">> Saving tokenizer files locally..."
python3 - <<PYEOF
import json
from transformers import AutoTokenizer, AutoConfig

tok = AutoTokenizer.from_pretrained("${MODEL_ID}")
tok.save_pretrained("${TOKENIZER_DIR}")

# Read the model's own config to find forced_bos_token_id, which is how the
# official HF usage snippet (model.generate(...) with no explicit lang args)
# knows to produce Kinyarwanda output. We reuse the same value instead of
# guessing a language code, so behavior matches the model card exactly.
cfg = AutoConfig.from_pretrained("${MODEL_ID}")
forced_id = getattr(cfg, "forced_bos_token_id", None)
info = {"forced_bos_token_id": forced_id}
if forced_id is not None:
    info["forced_bos_token"] = tok.convert_ids_to_tokens([forced_id])[0]
    print(f"Found forced_bos_token_id={forced_id} -> token '{info['forced_bos_token']}'")
else:
    print("No forced_bos_token_id in model config; app.py will fall back to TGT_LANG env var.")

with open("${TOKENIZER_DIR}/model_info.json", "w") as f:
    json.dump(info, f)

print("Tokenizer saved to ${TOKENIZER_DIR}")
PYEOF

echo ">> Done. CTranslate2 model in ./${OUT_DIR}, tokenizer in ./${TOKENIZER_DIR}"
echo ">> You can now run: uvicorn app:app --host 0.0.0.0 --port 8000"
