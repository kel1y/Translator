#!/usr/bin/env bash
# Downloads Maxime-Bakunzi/twigane-en-kin-translation from Hugging Face and
# converts it into an int8-quantized CTranslate2 model for fast CPU inference.
#
# IMPORTANT: the config.json shipped in that repo is broken — it's a custom
# 4-key metadata file, not a real transformers config (no model_type, no
# architecture info). Loading it directly fails with
# "Unrecognized model ... Should have a `model_type` key in its config.json"
# for BOTH the ct2 converter and plain `AutoModelForSeq2SeqLM.from_pretrained`
# (i.e. the usage snippet on the model card would fail too, as-is).
#
# Twigane is a fine-tune of mbazaNLP/Nllb_finetuned_general_en_kin (same
# architecture, same tokenizer family), so we pull that model's real
# config.json and swap it in before converting. Everything else (weights,
# tokenizer) comes from Twigane itself.
#
# Run this ONCE before starting the API. It needs internet access to
# huggingface.co and will take a few minutes (downloads ~5.5GB of fp32
# weights, converted int8 output is much smaller, ~1.3GB).

set -euo pipefail

MODEL_ID="Maxime-Bakunzi/twigane-en-kin-translation"
BASE_MODEL_ID="mbazaNLP/Nllb_finetuned_general_en_kin"
RAW_DIR="twigane_raw"
OUT_DIR="ct2_model"
TOKENIZER_DIR="tokenizer"

echo ">> Downloading ${MODEL_ID} (weights + tokenizer) ..."
python3 - <<PYEOF
from huggingface_hub import snapshot_download, hf_hub_download

snapshot_download(repo_id="${MODEL_ID}", local_dir="${RAW_DIR}")

print(">> Fetching the real config.json from ${BASE_MODEL_ID} (Twigane's own config.json is incomplete)...")
fixed_config = hf_hub_download(repo_id="${BASE_MODEL_ID}", filename="config.json")

import shutil
shutil.copyfile(fixed_config, "${RAW_DIR}/config.json")
print("Patched ${RAW_DIR}/config.json with the base model's real config.")
PYEOF

echo ">> Converting to CTranslate2 (int8 quantization)..."
ct2-transformers-converter \
  --model "${RAW_DIR}" \
  --output_dir "${OUT_DIR}" \
  --quantization int8 \
  --force

echo ">> Cleaning up raw fp32 weights (~5.5GB) now that the int8 model exists..."
rm -rf "${RAW_DIR}"
rm -rf /root/.cache/huggingface/hub
pip cache purge 2>/dev/null || true

echo ">> Saving tokenizer files locally..."
python3 - <<PYEOF
from transformers import AutoTokenizer
# Twigane's own tokenizer files ARE complete and valid (only config.json was
# broken), so we load the tokenizer straight from the model repo.
tok = AutoTokenizer.from_pretrained("${MODEL_ID}")
tok.save_pretrained("${TOKENIZER_DIR}")
print("Tokenizer saved to ${TOKENIZER_DIR}")
PYEOF

echo ">> Done. CTranslate2 model in ./${OUT_DIR}, tokenizer in ./${TOKENIZER_DIR}"
echo ">> You can now run: uvicorn app:app --host 0.0.0.0 --port 8001"
