import os
import json
import time
import logging

import ctranslate2
from transformers import AutoTokenizer
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("kin-translate-api")

CT2_MODEL_DIR = os.environ.get("CT2_MODEL_DIR", "ct2_model")
TOKENIZER_DIR = os.environ.get("TOKENIZER_DIR", "tokenizer")
SRC_LANG = os.environ.get("SRC_LANG", "eng_Latn")
TGT_LANG = os.environ.get("TGT_LANG", "kin_Latn")

# CPU thread tuning. On a small VPS, keep intra_threads modest so the API
# stays responsive under concurrent requests instead of one request hogging
# every core. Override via env vars if you have more cores to spare.
INTER_THREADS = int(os.environ.get("CT2_INTER_THREADS", "1"))
INTRA_THREADS = int(os.environ.get("CT2_INTRA_THREADS", "4"))
BEAM_SIZE = int(os.environ.get("BEAM_SIZE", "4"))
MAX_INPUT_LENGTH = int(os.environ.get("MAX_INPUT_LENGTH", "512"))

app = FastAPI(title="English → Kinyarwanda Translation API", version="1.0")

translator = None
tokenizer = None
tgt_prefix_token = None


class TranslateRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=5000, description="English text to translate.")
    beam_size: int | None = Field(None, ge=1, le=8, description="Optional override for beam search width.")


class TranslateResponse(BaseModel):
    translation: str
    source_lang: str
    target_lang: str
    latency_ms: float


class BatchTranslateRequest(BaseModel):
    texts: list[str] = Field(..., min_length=1, max_length=50)


class BatchTranslateResponse(BaseModel):
    translations: list[str]
    latency_ms: float


@app.on_event("startup")
def load_model():
    global translator, tokenizer, tgt_prefix_token

    if not os.path.isdir(CT2_MODEL_DIR):
        raise RuntimeError(
            f"CTranslate2 model directory '{CT2_MODEL_DIR}' not found. "
            "Run convert_model.sh first to download and convert the model."
        )
    if not os.path.isdir(TOKENIZER_DIR):
        raise RuntimeError(
            f"Tokenizer directory '{TOKENIZER_DIR}' not found. "
            "Run convert_model.sh first to download and convert the model."
        )

    log.info("Loading tokenizer from %s ...", TOKENIZER_DIR)
    tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_DIR, src_lang=SRC_LANG)

    # Prefer the model's own forced_bos_token_id (saved by convert_model.sh),
    # which is what makes the plain HF `model.generate(...)` snippet from the
    # model card work without passing any explicit language args. Fall back
    # to the TGT_LANG env var only if that info isn't available.
    global tgt_prefix_token
    info_path = os.path.join(TOKENIZER_DIR, "model_info.json")
    if os.path.isfile(info_path):
        with open(info_path) as f:
            info = json.load(f)
        if info.get("forced_bos_token"):
            tgt_prefix_token = info["forced_bos_token"]
            log.info("Using forced_bos_token from model config: '%s'", tgt_prefix_token)

    if tgt_prefix_token is None:
        vocab = tokenizer.get_vocab()
        if TGT_LANG not in vocab:
            raise RuntimeError(
                f"Target language token '{TGT_LANG}' not found in tokenizer vocab, and no "
                "forced_bos_token_id was found in the model config. Check "
                "tokenizer/model_info.json and special_tokens_map.json for the correct code."
            )
        tgt_prefix_token = TGT_LANG
        log.info("Using TGT_LANG env fallback: '%s'", tgt_prefix_token)

    log.info(
        "Loading CTranslate2 model from %s (inter_threads=%d, intra_threads=%d) ...",
        CT2_MODEL_DIR, INTER_THREADS, INTRA_THREADS,
    )
    translator = ctranslate2.Translator(
        CT2_MODEL_DIR,
        device="cpu",
        inter_threads=INTER_THREADS,
        intra_threads=INTRA_THREADS,
    )
    log.info("Model loaded. Ready to serve.")


def _translate_one(text: str, beam_size: int) -> str:
    tokens = tokenizer.convert_ids_to_tokens(tokenizer.encode(text))
    results = translator.translate_batch(
        [tokens],
        target_prefix=[[tgt_prefix_token]],
        beam_size=beam_size,
        max_decoding_length=MAX_INPUT_LENGTH,
    )
    output_tokens = results[0].hypotheses[0][1:]  # drop the leading lang token
    output_ids = tokenizer.convert_tokens_to_ids(output_tokens)
    return tokenizer.decode(output_ids, skip_special_tokens=True)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": translator is not None}


@app.post("/translate", response_model=TranslateResponse)
def translate(req: TranslateRequest):
    if translator is None:
        raise HTTPException(status_code=503, detail="Model is still loading, try again shortly.")
    start = time.time()
    try:
        translation = _translate_one(req.text, req.beam_size or BEAM_SIZE)
    except Exception as e:
        log.exception("Translation failed")
        raise HTTPException(status_code=500, detail=f"Translation failed: {e}")
    latency_ms = (time.time() - start) * 1000
    return TranslateResponse(
        translation=translation,
        source_lang=SRC_LANG,
        target_lang=TGT_LANG,
        latency_ms=round(latency_ms, 1),
    )


@app.post("/translate/batch", response_model=BatchTranslateResponse)
def translate_batch(req: BatchTranslateRequest):
    if translator is None:
        raise HTTPException(status_code=503, detail="Model is still loading, try again shortly.")
    start = time.time()
    try:
        all_tokens = [tokenizer.convert_ids_to_tokens(tokenizer.encode(t)) for t in req.texts]
        results = translator.translate_batch(
            all_tokens,
            target_prefix=[[tgt_prefix_token]] * len(all_tokens),
            beam_size=BEAM_SIZE,
            max_decoding_length=MAX_INPUT_LENGTH,
        )
        translations = []
        for r in results:
            output_tokens = r.hypotheses[0][1:]
            output_ids = tokenizer.convert_tokens_to_ids(output_tokens)
            translations.append(tokenizer.decode(output_ids, skip_special_tokens=True))
    except Exception as e:
        log.exception("Batch translation failed")
        raise HTTPException(status_code=500, detail=f"Translation failed: {e}")
    latency_ms = (time.time() - start) * 1000
    return BatchTranslateResponse(translations=translations, latency_ms=round(latency_ms, 1))
