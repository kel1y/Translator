#!/usr/bin/env bash
# Quick smoke test against a running instance of the API.
# Usage: ./test_api.sh [host:port]
HOST="${1:-localhost:8001}"

echo ">> Health check"
curl -s "http://${HOST}/health" | python3 -m json.tool

echo -e "\n>> Single translation"
curl -s -X POST "http://${HOST}/translate" \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, how are you today?"}' | python3 -m json.tool

echo -e "\n>> Batch translation"
curl -s -X POST "http://${HOST}/translate/batch" \
  -H "Content-Type: application/json" \
  -d '{"texts": ["Good morning", "Where is the market?", "Thank you very much"]}' | python3 -m json.tool
